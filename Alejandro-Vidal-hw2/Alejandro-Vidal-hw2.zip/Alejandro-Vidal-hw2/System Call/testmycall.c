/*---Start of the C file---*/
#include<stdio.h>
#include "testmycall.h"
int main (void)
{
printf("%d\n", syscall(__NR_alejandro_vidal, 5913959));
}

/*---ENd of the C file---*/
